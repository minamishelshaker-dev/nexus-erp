"""
Nexus ERP Core Module
"""
