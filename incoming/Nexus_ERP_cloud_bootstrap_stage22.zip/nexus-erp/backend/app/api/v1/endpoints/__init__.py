"""
Nexus ERP API Endpoints
"""
